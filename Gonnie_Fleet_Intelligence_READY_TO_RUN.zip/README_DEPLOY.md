# Gonnie Fleet Intelligence — Ready-to-Run Pack

## 1. Supabase
Open Supabase -> SQL Editor and run:

`supabase/migrations/001_complete_schema.sql`

Run it once. It is designed to be safely re-run.

## 2. GitHub
Replace the repository's `app.py` with the supplied `app.py`.

Replace `requirements.txt` with the supplied `requirements.txt`.

Do NOT upload `.streamlit/secrets.toml` containing real keys.

## 3. Streamlit Cloud
Open your app -> Settings -> Secrets and add:

```toml
SUPABASE_URL = "https://YOUR_PROJECT.supabase.co"
SUPABASE_PUBLISHABLE_KEY = "YOUR_SUPABASE_PUBLISHABLE_KEY"
```

Save and reboot/redeploy.

## 4. First login
The configured Master Admin email is `gerswilledavids@gmail.com`.

Every normal signup automatically receives a new isolated tenant/workspace.

## 5. Yoco
Payment secrets must stay server-side in the Supabase Edge Function. The Streamlit app does not contain a Yoco private secret.

If the Yoco Edge Function is not deployed yet, Billing remains informational and the rest of the fleet app still runs.

## 6. Important
Never paste Supabase service-role keys, Yoco private keys, passwords, or other secrets into GitHub source code.
