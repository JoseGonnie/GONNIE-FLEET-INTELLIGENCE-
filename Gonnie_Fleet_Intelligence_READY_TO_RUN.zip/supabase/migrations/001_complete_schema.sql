create extension if not exists pgcrypto;

-- =========================================================
-- GONNIE FLEET INTELLIGENCE - COMPLETE BASE SCHEMA
-- Run this once in Supabase SQL Editor.
-- =========================================================

create table if not exists public.tenants (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  status text not null default 'active',
  created_at timestamptz not null default now()
);

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  email text,
  role text not null default 'tenant_admin'
    check (role in ('master_admin','tenant_admin','fleet_manager','driver','viewer')),
  tenant_id uuid references public.tenants(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.vehicles (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  registration text,
  fleet_no text,
  make text,
  model text,
  year integer,
  vin_engine_no text,
  status text default 'Active',
  expected_km_l numeric default 2.0,
  service_cost_per_km numeric default 0,
  monthly_insurance numeric default 0,
  next_service_km numeric default 0,
  avg_daily_km numeric default 0,
  fleet_health_score numeric default 100,
  current_odometer numeric default 0,
  annual_license_cost numeric default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.drivers (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  driver_name text,
  driver_phone text,
  license_number text,
  license_expiry date,
  prdp_expiry date,
  supervisor text,
  rating numeric default 0,
  avg_driver_score numeric default 0,
  accidents integer default 0,
  fines integer default 0,
  status text default 'Active',
  created_at timestamptz not null default now()
);

create table if not exists public.trips (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  trip_date date default current_date,
  vehicle_id uuid references public.vehicles(id) on delete set null,
  driver_name text,
  start_location text,
  end_location text,
  cargo_type text,
  load_kg numeric default 0,
  odo_start numeric default 0,
  odo_end numeric default 0,
  distance_km numeric default 0,
  gps_distance_km numeric default 0,
  fuel_used_liters numeric default 0,
  cost_per_liter numeric default 0,
  fixed_cost numeric default 0,
  variable_cost numeric,
  revenue numeric default 0,
  paid_status text default 'Unpaid',
  expected_km_l numeric default 2.0,
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.maintenance_log (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  vehicle_id uuid references public.vehicles(id) on delete set null,
  service_type text,
  service_date date,
  cost numeric default 0,
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.gps_tracker_log (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  vehicle_id text,
  latitude numeric,
  longitude numeric,
  recorded_at timestamptz default now(),
  speed_kmh numeric,
  ignition_status text,
  created_at timestamptz not null default now()
);

create table if not exists public.billing_subscriptions (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  plan text default 'starter',
  status text default 'active',
  yoco_customer_id text,
  yoco_subscription_id text,
  current_period_start timestamptz,
  current_period_end timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_user_id uuid,
  actor_role text,
  tenant_id uuid references public.tenants(id) on delete set null,
  table_name text,
  record_id text,
  action text,
  old_data jsonb,
  new_data jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.compliance (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  driver_id uuid references public.drivers(id) on delete cascade,
  document_type text,
  expiry_date date,
  status text,
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.fuel_analysis (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  vehicle_id uuid references public.vehicles(id) on delete set null,
  period_date date,
  litres numeric default 0,
  distance_km numeric default 0,
  km_per_l numeric default 0,
  expected_km_l numeric default 0,
  variance_pct numeric default 0,
  theft_alert boolean default false,
  created_at timestamptz not null default now()
);

create table if not exists public.financial_forecast (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  period_date date,
  projected_revenue numeric default 0,
  projected_cost numeric default 0,
  projected_profit numeric default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.invite_codes (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  code text unique not null,
  role text default 'viewer',
  used boolean default false,
  expires_at timestamptz,
  created_at timestamptz not null default now()
);

create index if not exists idx_profiles_tenant on public.profiles(tenant_id);
create index if not exists idx_vehicles_tenant on public.vehicles(tenant_id);
create index if not exists idx_drivers_tenant on public.drivers(tenant_id);
create index if not exists idx_trips_tenant on public.trips(tenant_id);
create index if not exists idx_maintenance_tenant on public.maintenance_log(tenant_id);
create index if not exists idx_gps_tenant on public.gps_tracker_log(tenant_id);
create index if not exists idx_billing_tenant on public.billing_subscriptions(tenant_id);
create index if not exists idx_audit_tenant on public.audit_logs(tenant_id);

create or replace function public.current_user_role()
returns text
language sql
stable
security definer
set search_path = public
as $$
  select role from public.profiles where id = auth.uid();
$$;

create or replace function public.current_user_tenant_id()
returns uuid
language sql
stable
security definer
set search_path = public
as $$
  select tenant_id from public.profiles where id = auth.uid();
$$;

grant execute on function public.current_user_role() to authenticated;
grant execute on function public.current_user_tenant_id() to authenticated;

alter table public.tenants enable row level security;
alter table public.profiles enable row level security;
alter table public.vehicles enable row level security;
alter table public.drivers enable row level security;
alter table public.trips enable row level security;
alter table public.maintenance_log enable row level security;
alter table public.gps_tracker_log enable row level security;
alter table public.billing_subscriptions enable row level security;
alter table public.audit_logs enable row level security;
alter table public.compliance enable row level security;
alter table public.fuel_analysis enable row level security;
alter table public.financial_forecast enable row level security;
alter table public.invite_codes enable row level security;

-- Remove older policies with the same names so this script is safe to re-run.
do $$
declare r record;
begin
  for r in
    select schemaname, tablename, policyname
    from pg_policies
    where schemaname = 'public'
      and tablename in (
        'tenants','profiles','vehicles','drivers','trips','maintenance_log',
        'gps_tracker_log','billing_subscriptions','audit_logs','compliance',
        'fuel_analysis','financial_forecast','invite_codes'
      )
  loop
    execute format('drop policy if exists %I on %I.%I',
                   r.policyname, r.schemaname, r.tablename);
  end loop;
end $$;

create policy tenants_select on public.tenants
for select to authenticated
using (
  public.current_user_role() = 'master_admin'
  or id = public.current_user_tenant_id()
);

create policy tenants_master_write on public.tenants
for all to authenticated
using (public.current_user_role() = 'master_admin')
with check (public.current_user_role() = 'master_admin');

create policy profiles_select on public.profiles
for select to authenticated
using (
  id = auth.uid()
  or public.current_user_role() = 'master_admin'
  or tenant_id = public.current_user_tenant_id()
);

create policy profiles_update_self on public.profiles
for update to authenticated
using (id = auth.uid() or public.current_user_role() = 'master_admin')
with check (
  public.current_user_role() = 'master_admin'
  or (
    id = auth.uid()
    and tenant_id = public.current_user_tenant_id()
    and role = (select p.role from public.profiles p where p.id = auth.uid())
  )
);

create policy profiles_master_insert on public.profiles
for insert to authenticated
with check (public.current_user_role() = 'master_admin' or id = auth.uid());

-- Generic tenant CRUD policies.
do $$
declare t text;
begin
  foreach t in array array[
    'vehicles','drivers','trips','maintenance_log','gps_tracker_log',
    'billing_subscriptions','compliance','fuel_analysis',
    'financial_forecast','invite_codes'
  ]
  loop
    execute format(
      'create policy %I on public.%I for select to authenticated using (
         public.current_user_role() = ''master_admin''
         or tenant_id = public.current_user_tenant_id()
       )', t || '_select', t);

    execute format(
      'create policy %I on public.%I for insert to authenticated with check (
         public.current_user_role() = ''master_admin''
         or tenant_id = public.current_user_tenant_id()
       )', t || '_insert', t);

    execute format(
      'create policy %I on public.%I for update to authenticated using (
         public.current_user_role() = ''master_admin''
         or tenant_id = public.current_user_tenant_id()
       ) with check (
         public.current_user_role() = ''master_admin''
         or tenant_id = public.current_user_tenant_id()
       )', t || '_update', t);

    execute format(
      'create policy %I on public.%I for delete to authenticated using (
         public.current_user_role() = ''master_admin''
         or tenant_id = public.current_user_tenant_id()
       )', t || '_delete', t);
  end loop;
end $$;

create policy audit_select on public.audit_logs
for select to authenticated
using (
  public.current_user_role() = 'master_admin'
  or tenant_id = public.current_user_tenant_id()
);

create policy audit_insert on public.audit_logs
for insert to authenticated
with check (
  auth.uid() is not null
  and (
    public.current_user_role() = 'master_admin'
    or tenant_id = public.current_user_tenant_id()
  )
);

-- Signup trigger:
-- Master Admin keeps the configured platform email.
-- Every normal signup gets a private tenant automatically.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  new_tenant uuid;
  company text;
  display_name text;
begin
  company := nullif(trim(coalesce(new.raw_user_meta_data->>'company_name','')), '');
  display_name := nullif(trim(coalesce(new.raw_user_meta_data->>'full_name','')), '');

  if lower(new.email) = lower('gerswilledavids@gmail.com') then
    insert into public.profiles(id, full_name, email, role, tenant_id)
    values (new.id, display_name, new.email, 'master_admin', null)
    on conflict (id) do update
      set full_name = excluded.full_name,
          email = excluded.email,
          role = 'master_admin';
    return new;
  end if;

  if company is null then
    company := split_part(coalesce(new.email,''), '@', 1);
  end if;

  insert into public.tenants(name)
  values (company)
  returning id into new_tenant;

  insert into public.profiles(id, full_name, email, role, tenant_id)
  values (new.id, display_name, new.email, 'tenant_admin', new_tenant)
  on conflict (id) do update
    set full_name = excluded.full_name,
        email = excluded.email,
        tenant_id = excluded.tenant_id;

  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute function public.handle_new_user();

-- Optional Yoco RPC compatibility functions. They deliberately do not expose secrets.
create or replace function public.get_yoco_secret_status_for_master_admin()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
begin
  if public.current_user_role() <> 'master_admin' then
    raise exception 'Master Admin access required';
  end if;
  return jsonb_build_object('status','SERVER_SIDE_ONLY','configured',false);
end;
$$;

create or replace function public.set_yoco_secret_for_master_admin(secret_value text)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
begin
  if public.current_user_role() <> 'master_admin' then
    raise exception 'Master Admin access required';
  end if;
  -- Do not store payment secrets in a normal table.
  -- Configure the Yoco secret in Supabase Edge Function secrets instead.
  return false;
end;
$$;

grant execute on function public.get_yoco_secret_status_for_master_admin() to authenticated;
grant execute on function public.set_yoco_secret_for_master_admin(text) to authenticated;
